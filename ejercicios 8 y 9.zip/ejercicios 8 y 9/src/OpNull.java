public class OpNull {
    public static void main(String args[]){
        promptUser();

    }
    private static void promptUser() {
        String name = "Franquito";

        if (name == null || name.trim().isEmpty()) {

            System.out.println("no entro su nombre");
        } else {
            System.out.println("entro su nombre: " + name);
        }

    }

}